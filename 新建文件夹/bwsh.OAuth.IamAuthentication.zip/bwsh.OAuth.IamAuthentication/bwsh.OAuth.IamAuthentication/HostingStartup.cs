﻿using Aras.OAuth.Server.Infrastructure;
using bwsh.OAuth.IamAuthentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

[assembly: HostingStartup(typeof(HostingStartup))]
namespace bwsh.OAuth.IamAuthentication
{
    public class HostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((hostingContext, services) =>
            {
                Assembly pluginAssembly = typeof(HostingStartup).Assembly;
                IConfiguration configuration = hostingContext.Configuration.GetPluginConfiguration(pluginAssembly);
                var pluginOptions = new PluginOptions();
                configuration.Bind(pluginOptions);
                services.Configure<PluginOptions>(configuration);

                services.AddAuthentication(options =>
                {
                    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;

                })
                .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddOAuth<IamOptions, IamHandler>(OpenIdConnectDefaults.AuthenticationScheme, pluginOptions.DisplayName, options =>
                {
                    options.Database = pluginOptions.Database;
                    options.PlmSecret = pluginOptions.PlmSecret;
                 
                    options.AuthorizationEndpoint = pluginOptions.Instance;
                    options.TokenEndpoint = pluginOptions.TokenEndpoint;
                    options.UserInformationEndpoint = pluginOptions.UserInformationEndpoint;
                    options.CallbackPath = pluginOptions.CallbackPath;
                    options.ClientId = pluginOptions.ClientId;
                    options.ClientSecret = pluginOptions.ClientSecret;                    
                    options.Scope.Clear();
                    options.Scope.Add("user");
                    options.SaveTokens = true;
                    options.UsePkce = false;
                });             
            });
            Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true;
        }
    }
}
